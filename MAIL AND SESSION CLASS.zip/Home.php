<!doctype html>
<html lang="en">
    <head>
        <title>Title</title>
        <!-- Required meta tags -->
        <meta charset="utf-8" />
        <meta
            name="viewport"
            content="width=device-width, initial-scale=1, shrink-to-fit=no"
        />

        <!-- Bootstrap CSS v5.2.1 -->
        <link
            href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css"
            rel="stylesheet"
            integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
            crossorigin="anonymous"
        />
    </head>

    <body>
        <header>
            <!-- place navbar here -->
        </header>
        <main>

        <?php 
        $host = "localhost";
        $id="root";
        $pass="";
        $db="employees";
        $conn = mysqli_connect($host,$id,$pass,$db);
        $sql="Select * from empinfo";
        $res = mysqli_query($conn,$sql);
        session_start();
        if(!isset($_SESSION["uname"] )&& !isset($_SESSION["upass"])){
               header("Location:Login.html");
        }
        if(mysqli_num_rows($res)>0){

            echo"    <div class='container mt-5'>
            <div class='table-responsive'>
              <table class='table table-hover'>
                <thead>
                  <tr>
                    <th scope='col'>ID</th>
                    <th scope='col'>Name</th>
                    <th scope='col'>Email</th>
                    <th scope='col'>Action</th>
                  </tr>
                </thead>
                <tbody>";
                while($data = mysqli_fetch_assoc($res)){
                    echo"
                    <tr class=''>
                      <td scope='row'>{$data['ID']}</td>
                      <td scope='row'>{$data['Name']}</td>
                      <td scope='row'>{$data['Email']}</td>
                      <td scope='row'>
                      <a href='remove_user.php?id={$data['ID']}'><button type='button' class='btn btn-danger mx-3'>DELETE</button></a>
                      <a href='edit_user.php?id={$data['ID']}'><button type='button' class='btn btn-warning'>EDIT</button></a>
                      </td>
                    </tr>
                    ";
                }

                echo"</tbody>
                </table>
              </div>
            </div>
            
            
            ";
        }else{
            echo"<h3 class='text-center my-5'> NO RECORDS FOUND</h3>";
        } 
        ?>

        <div class="container  ">

        <a href="logout.php">
       <button
        type="button"
        class="btn btn-danger"
       >
        Logout
       </button></a>
       
        </div>


        
        </main>
        <footer>
            <!-- place footer here -->
        </footer>
        <!-- Bootstrap JavaScript Libraries -->
        <script
            src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
            integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
            crossorigin="anonymous"
        ></script>

        <script
            src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js"
            integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+"
            crossorigin="anonymous"
        ></script>
    </body>
</html>
