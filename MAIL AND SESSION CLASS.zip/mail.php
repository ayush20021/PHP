<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;


require 'A:\XA\htdocs\MAILER\src\Exception.php';
require 'A:\XA\htdocs\MAILER\src\PHPMailer.php';
require 'A:\XA\htdocs\MAILER\src\SMTP.php';

$mail = new PHPMailer(true);

$email = 'ayush99kumar12@gmail.com';
$password = 'wweu amsp guix twdk';

try {
    // Configure SMTP settings
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com';
    $mail->SMTPAuth = true;
    $mail->Username = $email;
    $mail->Password = $password;
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
    $mail->Port = 25;

    // Recipient information
    $mail->setFrom($email, 'Ayush');
    $mail->addAddress('aroy79972@gmail.com', 'demo');
    $mail->addReplyTo($email, 'labdemo');

    // //Attachments
    // $mail->addAttachment('Chrysanthemum.jpg', 'Chrysanthemum.jpg');


    // Email content
    $mail->isHTML(true);
    $mail->Subject = 'Test Email from Localhost';
    $mail->Body    = 'This is a test email sent from localhost using PHPMailer and Gmail SMTP.';

    $mail->send();
    echo 'Email sent successfully';
} catch (Exception $e) {
    echo 'Failed to send email: ', $mail->ErrorInfo;
}
